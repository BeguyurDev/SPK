/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Admin
 */
public class m_Data_Bobot_Atribut_DAO {
    Connection kon;
    
    public m_Data_Bobot_Atribut_DAO() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            kon = DriverManager.getConnection(
                    "jdbc:mysql://localhost/bantuantuhan",
                    "root", "");
        } catch (ClassNotFoundException | SQLException e) {
        }
    }
    
    public double get_wParents(int id){
        double value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getDouble(10);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int get_bobotParents(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(2);
            }

        } catch (Exception e) {

        }
        return value;
    }

    public double get_wForm(int id){
        double value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getDouble(11);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int get_bobotForm(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(3);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public double get_wChildren(int id){
        double value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getDouble(12);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int get_bobotChildren(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(4);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public double get_wHousing(int id){
        double value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getDouble(13);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int get_bobotHousing(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(5);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public double get_wFinance(int id){
        double value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getDouble(14);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int get_bobotFinance(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(6);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public double get_wSocial(int id){
        double value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getDouble(15);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int get_bobotSocial(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(7);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public double get_wHealth(int id){
        double value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getDouble(16);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int get_bobotHealth(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `bobot_atribut` WHERE `id_kriteria` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(8);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public void update_Atribut (m_Data_Bobot_Atribut atribut){
        try {
            String sql_update = "UPDATE `bobot_atribut` SET `parents`=?, `form`=?,`children`=?, "
                    + "`housing`=?, `finance`=?, `social`=?, `health`=?, `jumlah_bobot_atribut`=?, "
                    + "`w_parents`=?, `w_form`=?, `w_children`=?, `w_housing`=?, `w_finance`=?, "
                    + "`w_social`=?, `w_health`=? WHERE `id_kriteria`='"+1+"'";
            
            PreparedStatement statement = kon.prepareStatement(sql_update);
            statement.setInt(1, atribut.getParents());
            statement.setInt(2, atribut.getForm());
            statement.setInt(3, atribut.getChildren());
            statement.setInt(4, atribut.getHousing());
            statement.setInt(5, atribut.getFinance());
            statement.setInt(6, atribut.getSocial());
            statement.setInt(7, atribut.getHealth());
            statement.setInt(8, atribut.getSum());
            statement.setDouble(9, atribut.getW1());
            statement.setDouble(10, atribut.getW2());
            statement.setDouble(11, atribut.getW3());
            statement.setDouble(12, atribut.getW4());
            statement.setDouble(13, atribut.getW5());
            statement.setDouble(14, atribut.getW6());
            statement.setDouble(15, atribut.getW7());
            
            statement.executeUpdate();
            
        } catch(Exception e){
            System.out.println(e);
        }
    }
}