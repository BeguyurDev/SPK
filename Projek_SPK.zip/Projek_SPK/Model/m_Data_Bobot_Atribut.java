/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Admin
 */
public class m_Data_Bobot_Atribut {
    int id,parents,form,children,housing,finance,social,health,sum;
    double w1,w2,w3,w4,w5,w6,w7;
    
    //konstruktor
    public m_Data_Bobot_Atribut(int id, int parents, int form, int children, int housing, int finance, int social, int health, int sum, double w1, double w2, double w3, double w4, double w5, double w6, double w7) {
        this.id = id;
        this.parents = parents;
        this.form = form;
        this.children = children;
        this.housing = housing;
        this.finance = finance;
        this.social = social;
        this.health = health;
        this.sum = sum;
        this.w1 = w1;
        this.w2 = w2;
        this.w3 = w3;
        this.w4 = w4;
        this.w5 = w5;
        this.w6 = w6;
        this.w7 = w7;
    }
    
    public m_Data_Bobot_Atribut(int parents, int form, int children, int housing, int finance, int social, int health, int sum, double w1, double w2, double w3, double w4, double w5, double w6, double w7) {
        
        this.parents = parents;
        this.form = form;
        this.children = children;
        this.housing = housing;
        this.finance = finance;
        this.social = social;
        this.health = health;
        this.sum = sum;
        this.w1 = w1;
        this.w2 = w2;
        this.w3 = w3;
        this.w4 = w4;
        this.w5 = w5;
        this.w6 = w6;
        this.w7 = w7;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getParents() {
        return parents;
    }

    public void setParents(int parents) {
        this.parents = parents;
    }

    public int getForm() {
        return form;
    }

    public void setForm(int form) {
        this.form = form;
    }

    public int getChildren() {
        return children;
    }

    public void setChildren(int children) {
        this.children = children;
    }

    public int getHousing() {
        return housing;
    }

    public void setHousing(int housing) {
        this.housing = housing;
    }

    public int getFinance() {
        return finance;
    }

    public void setFinance(int finance) {
        this.finance = finance;
    }

    public int getSocial() {
        return social;
    }

    public void setSocial(int social) {
        this.social = social;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getSum() {
        return sum;
    }

    public void setSum(int sum) {
        this.sum = sum;
    }

    public double getW1() {
        return w1;
    }

    public void setW1(double w1) {
        this.w1 = w1;
    }

    public double getW2() {
        return w2;
    }

    public void setW2(double w2) {
        this.w2 = w2;
    }

    public double getW3() {
        return w3;
    }

    public void setW3(double w3) {
        this.w3 = w3;
    }

    public double getW4() {
        return w4;
    }

    public void setW4(double w4) {
        this.w4 = w4;
    }

    public double getW5() {
        return w5;
    }

    public void setW5(double w5) {
        this.w5 = w5;
    }

    public double getW6() {
        return w6;
    }

    public void setW6(double w6) {
        this.w6 = w6;
    }

    public double getW7() {
        return w7;
    }

    public void setW7(double w7) {
        this.w7 = w7;
    }
    
}
