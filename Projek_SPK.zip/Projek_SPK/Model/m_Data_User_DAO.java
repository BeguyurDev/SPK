/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class m_Data_User_DAO {
    Connection kon;
    
    public m_Data_User_DAO() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            kon = DriverManager.getConnection(
                    "jdbc:mysql://localhost/bantuantuhan",
                    "root", "");
        } catch (ClassNotFoundException | SQLException e) {
        }
    }
    
    public String getPassword(String email){
        String value = "";
        try {
            String sql_select = "SELECT * FROM `data_user` WHERE `email` = '" + email + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getString(3);
            }

        } catch (Exception e) {

        }
        return value;
    }
}
