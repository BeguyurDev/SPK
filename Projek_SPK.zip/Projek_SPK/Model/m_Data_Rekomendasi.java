/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Admin
 */
public class m_Data_Rekomendasi {
    int id, rank;
    double hasilVektor_S, hasilVektor_V, jumlah_VektorS;
    String nama, tgl_lahir;

    public m_Data_Rekomendasi() {
    }    
    
    //konstruktor
    public m_Data_Rekomendasi(int id, int rank, String nama, String tgl_lahir, double hasilVektor_S, double jumlah_VektorS, double hasilVektor_V) {
        this.id = id;
        this.rank = rank;
        this.tgl_lahir = tgl_lahir;
        this.hasilVektor_S = hasilVektor_S;
        this.jumlah_VektorS = jumlah_VektorS;
        this.hasilVektor_V = hasilVektor_V;
        this.nama = nama;
    }
    
    public m_Data_Rekomendasi(String nama, String tgl_lahir, double hasilVektor_S, double jumlah_VektorS, double hasilVektor_V) {
        this.tgl_lahir = tgl_lahir;
        this.hasilVektor_S = hasilVektor_S;
        this.jumlah_VektorS = jumlah_VektorS;
        this.hasilVektor_V = hasilVektor_V;
        this.nama = nama;
    }
    
    //konstruktor untuk update jumlah vektorS
//    public m_Data_Rekomendasi(int id, double jumlah_VektorS) {
//        this.id = id;
//        this.jumlah_VektorS = jumlah_VektorS;
//    }
    
    //konstruktor untuk update vektorV
//    public m_Data_Rekomendasi(int id, double vektorV) {
//        this.id = id;
//        this.hasilVektor_V = vektorV;
//    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public int getRank() {
        return rank;
    }
    
    public void setRank() {
        this.rank = rank;
    }

    public double getHasilVektor_S() {
        return hasilVektor_S;
    }

    public void setHasilVektor_S(double hasilVektor_S) {
        this.hasilVektor_S = hasilVektor_S;
    }

    public double getHasilVektor_V() {
        return hasilVektor_V;
    }

    public void setHasilVektor_V(double hasilVektor_V) {
        this.hasilVektor_V = hasilVektor_V;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTgl_lahir() {
        return tgl_lahir;
    }

    public void setTgl_lahir(String tgl_lahir) {
        this.tgl_lahir = tgl_lahir;
    }

    public double getJumlah_VektorS() {
        return jumlah_VektorS;
    }

    public void setJumlah_VektorS(double jumlah_VektorS) {
        this.jumlah_VektorS = jumlah_VektorS;
    }
    
    
}
