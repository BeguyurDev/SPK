/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Admin
 */
public class m_Data_Siswa {
    int id, parents, form, children, housing, finance, social, health;
    String nama, tgl_lahir;
    
    public m_Data_Siswa(String tgl_lahir) {
        
        this.tgl_lahir = tgl_lahir;
        
    }
    
    public m_Data_Siswa(int id, String nama, String tgl_lahir, int parents, int form, int children, int housing, int finance, int social, int health) {
        this.id = id;
        this.nama = nama;
        this.tgl_lahir = tgl_lahir;
        this.parents = parents;
        this.form = form;
        this.children = children;
        this.housing = housing;
        this.finance = finance;
        this.social = social;
        this.health = health;
    }
    
    public m_Data_Siswa(String nama, String tgl_lahir, int parents, int form, int children, int housing, int finance, int social, int health) {
        
        this.nama = nama;
        this.tgl_lahir = tgl_lahir;
        this.parents = parents;
        this.form = form;
        this.children = children;
        this.housing = housing;
        this.finance = finance;
        this.social = social;
        this.health = health;
    }
    public m_Data_Siswa (int id) {
        this.id = id;
    }
    
    public m_Data_Siswa (String nama, String tgl) {
        this.nama=nama;
        this.tgl_lahir=tgl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getParents() {
        return parents;
    }

    public void setParents(int parents) {
        this.parents = parents;
    }

    public int getForm() {
        return form;
    }

    public void setForm(int form) {
        this.form = form;
    }

    public int getChildren() {
        return children;
    }

    public void setChildren(int children) {
        this.children = children;
    }

    public int getHousing() {
        return housing;
    }

    public void setHousing(int housing) {
        this.housing = housing;
    }

    public int getFinance() {
        return finance;
    }

    public void setFinance(int finance) {
        this.finance = finance;
    }

    public int getSocial() {
        return social;
    }

    public void setSocial(int social) {
        this.social = social;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTgl_lahir() {
        return tgl_lahir;
    }

    public void setTgl_lahir(String tgl_lahir) {
        this.tgl_lahir = tgl_lahir;
    }
    
}
