/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Admin
 */
public class m_Data_Rekomendasi_DAO {

    //variabel Global
    Connection kon;

    public m_Data_Rekomendasi_DAO() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            kon = DriverManager.getConnection(
                    "jdbc:mysql://localhost/bantuantuhan",
                    "root", "");
        } catch (ClassNotFoundException | SQLException e) {
        }
    }

    public List<m_Data_Rekomendasi> getAllDataPenerimaBantuan() {

        List<m_Data_Rekomendasi> list_PenerimaBantuan = new ArrayList<>();
        try {
            String sql_select = "SELECT * FROM `hasil_rekomendasi` order by vektorV desc";//order by vektorV desc limit 50
            PreparedStatement statement = kon.prepareStatement(sql_select);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                //ini data yg (disesuaikan dengan konstruktor) di class model Dta_Rekomendasi untuk penerima (m_Data_Rekomendasi)
                list_PenerimaBantuan.add(new m_Data_Rekomendasi(result.getInt(1), result.getInt(2), result.getString(3), result.getString(4), result.getDouble(5), result.getDouble(6), result.getDouble(7)));
            }
        } catch (Exception e) {
        }
        return list_PenerimaBantuan;
    }
    
    public List<m_Data_Rekomendasi> getData_by_NamadanTglLahir(String nama, String tgl) {

        List<m_Data_Rekomendasi> list_PenerimaBantuan = new ArrayList<>();
        try {
            String sql_select = "SELECT * FROM `hasil_rekomendasi` where nama like '%"+nama+"%' and tgl_lahir='"+tgl+"' order by vektorV desc" ;
            PreparedStatement statement = kon.prepareStatement(sql_select);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                //ini data yg (disesuaikan dengan konstruktor) di class model Dta_Rekomendasi untuk penerima (m_Data_Rekomendasi)
                list_PenerimaBantuan.add(new m_Data_Rekomendasi(result.getInt(1), result.getInt(2), result.getString(3), result.getString(4), result.getDouble(5), result.getDouble(6), result.getDouble(7)));
            }
        } catch (Exception e) {
        }
        return list_PenerimaBantuan;
    }

    public void Tambah(m_Data_Rekomendasi rekomendasi) {
        try {
            String sql_insert = "INSERT INTO `hasil_rekomendasi`"
                    + "( `id`,`rank`, `nama`, `tgl_lahir`, `vektorS`, `jumlah_vektorS`, `vektorV`) "
                    + "VALUES (?,?,?,?,?,?,?)";
            PreparedStatement statement = kon.prepareStatement(sql_insert);

            statement.setInt(1, rekomendasi.getId());
            statement.setInt(2, rekomendasi.getRank());
            statement.setString(3, rekomendasi.getNama());
            statement.setString(4, rekomendasi.getTgl_lahir());
            statement.setDouble(5, rekomendasi.getHasilVektor_S());
            statement.setDouble(6, rekomendasi.getJumlah_VektorS());
            statement.setDouble(7, rekomendasi.getHasilVektor_V());

            statement.executeUpdate();

        } catch (Exception e) {
            System.out.println(e+"tambah tb_hasil rekomendasi");
        }
    }

    
    public void update_VektorS(int id, double vektorS) {

            try {
                String sql_update = "update `hasil_rekomendasi` set `vektorS`= '"+vektorS+"' where `id`='"+id+"' ";
                PreparedStatement statement = kon.prepareStatement(sql_update);
                
                statement.executeUpdate();

            } catch (Exception e) {
                System.out.println(e+"update total vektorS");
            }
    }
    public void update_TotalVektorS(int id, double total_vektorS) {

            try {
                String sql_update = "update `hasil_rekomendasi` set `jumlah_vektorS`= '"+total_vektorS+"' where `id`='"+id+"' ";
                PreparedStatement statement = kon.prepareStatement(sql_update);
                
                statement.executeUpdate();
                
            } catch (Exception e) {
                System.out.println(e+"update vektorS");
            }
    }
    
    public void update_VektorV(int id, double vektorV) {

            try {
                String sql_update = "update `hasil_rekomendasi` set `vektorV`= '"+vektorV+"' where `id`='"+id+"' ";
                PreparedStatement statement = kon.prepareStatement(sql_update);
                
                statement.executeUpdate();
                
            } catch (Exception e) {
                System.out.println(e+"update total vektorV");
            }
    }
    
    public void update_Rank(int id, int rank){
        try {
                String sql_update = "update `hasil_rekomendasi` set `rank`= '"+rank+"' where `id`='"+id+"' ";
                PreparedStatement statement = kon.prepareStatement(sql_update);
                
                statement.executeUpdate();
                
            } catch (Exception e) {
                System.out.println(e+"update rank");
            }
    }
    
    public void hapusData (int id){
        try{
            String sql_delete = "DELETE FROM `hasil_rekomendasi` WHERE `id` = '"+id+"'";
            PreparedStatement statement = kon.prepareStatement(sql_delete);
            
            statement.execute();
            
        }catch (Exception e){
        }
    }

    public double getVektorS(int id) {
        double value = 0;
        try {
            String sql_select = "SELECT * FROM `hasil_rekomendasi` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getDouble(5);
            }

        } catch (Exception e) {

        }
        return value;
    }

    public double getTotalvektorS(int id) {
        double value = 0;
        try {
            String sql_select = "SELECT * FROM `hasil_rekomendasi` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getDouble(6);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public void updateData(int id, String nama, String tgl) {

            try {
                String sql_update = "update `hasil_rekomendasi` set `nama`= '"+nama+"', `tgl_lahir`='"+tgl+"' where `id`='"+id+"' ";
                PreparedStatement statement = kon.prepareStatement(sql_update);
                
                statement.executeUpdate();
                
            } catch (Exception e) {
                System.out.println(e+"update total vektorV");
            }
    }
}
