/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Admin
 */
public class m_Data_Siswa_DAO {
    Connection kon;
    
    public m_Data_Siswa_DAO() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            kon = DriverManager.getConnection(
                    "jdbc:mysql://localhost/bantuantuhan",
                    "root", "");
        } catch (ClassNotFoundException | SQLException e) {
        }
    }
    
    public List<m_Data_Siswa> getAllDataSiswa() {
        
        List<m_Data_Siswa> list_DataPribadiSiswa = new ArrayList<>();
        try {
            String sql_select = "SELECT * FROM data_siswa";
            PreparedStatement statement = kon.prepareStatement(sql_select);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                //ini data yg (disesuaikan dengan konstruktor) di class m_Data_Siswa
                list_DataPribadiSiswa.add(new m_Data_Siswa(result.getInt(1), result.getString(2), result.getString(3), result.getInt(4), result.getInt(5), result.getInt(6),
                result.getInt(7), result.getInt(8), result.getInt(9), result.getInt(10)));
            }
        } catch (Exception e) {
        }

        return list_DataPribadiSiswa;
    }
    
    public List<m_Data_Siswa> getDataby_NamadanTglLahir(String nama, String tgl) {
        
        List<m_Data_Siswa> list_DataPribadiSiswa = new ArrayList<>();
        try {
            String sql_select = "SELECT * FROM data_siswa where nama like'%"+nama+"%' and tgl_lahir='"+tgl+"'";
            PreparedStatement statement = kon.prepareStatement(sql_select);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                //ini data yg (disesuaikan dengan konstruktor) di class m_Data_Siswa
                list_DataPribadiSiswa.add(new m_Data_Siswa(result.getInt(1), result.getString(2), result.getString(3), result.getInt(4), result.getInt(5), result.getInt(6),
                result.getInt(7), result.getInt(8), result.getInt(9), result.getInt(10)));
            }
        } catch (Exception e) {
        }

        return list_DataPribadiSiswa;
    }
    
    public int getID(int id){
        int nilaiID = 0;
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                nilaiID = result.getInt(1);
            }

        } catch (Exception e) {

        }
        return nilaiID;
    }
    
    public int getID_byNamadanTglLahir(String nama, String tgl){
        int nilaiID = 0;
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `nama` like '" + nama + "' and `tgl_lahir`='"+tgl+"' ";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                nilaiID = result.getInt(1);
            }

        } catch (Exception e) {

        }
        return nilaiID;
    }
    
        public String getNama(int id){
        String value = "";
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getString(2);
            }

        } catch (Exception e) {

        }
        return value;
    }
        
        public String getTglLahir(int id){
        String value = "";
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getString(3);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int getBobotParentsSiswa(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(4);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int getBobotFormSiswa(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(5);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int getBobotChildrenSiswa(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(6);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int getBobotHousingSiswa(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(7);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int getBobotFinanceSiswa(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(8);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int getBobotSocialSiswa(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(9);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public int getBobotHealthSiswa(int id){
        int value = 0;
        try {
            String sql_select = "SELECT * FROM `data_siswa` WHERE `id` = '" + id + "'";
            PreparedStatement stmt = kon.prepareStatement(sql_select);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(10);
            }

        } catch (Exception e) {

        }
        return value;
    }
    
    public void editTglLahir(m_Data_Siswa siswa) {
        for (int i = 5; i < 301; i++) {
            
        try{
            String sql_update="update `data_siswa` set `tgl_lahir`= ? where `id`='"+i+"' ";
            PreparedStatement statement = kon.prepareStatement(sql_update);
            statement.setString(1, siswa.getTgl_lahir());
            statement.executeUpdate();
            
            statement.executeUpdate();
        }catch (Exception e){
            System.out.println(e);
        }
        }
    }
    
    public void Tambah(m_Data_Siswa siswa){
        try {
            String sql_insert = "INSERT INTO `data_siswa` "
                    + "(`id`, `nama`, `tgl_lahir`, `parents`, `form`, `children`, `housing`, `finance`, `social`, `health`) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?)";
            
            PreparedStatement statement=kon.prepareStatement(sql_insert);
            
            statement.setInt(1, siswa.getId());
            statement.setString(2, siswa.getNama());
            statement.setString(3, siswa.getTgl_lahir());
            statement.setInt(4, siswa.getParents());
            statement.setInt(5, siswa.getForm());
            statement.setInt(6, siswa.getChildren());
            statement.setInt(7, siswa.getHousing());
            statement.setInt(8, siswa.getFinance());
            statement.setInt(9, siswa.getSocial());
            statement.setInt(10, siswa.getHealth());

            statement.executeUpdate();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public void hapusData (int id){
        try{
            String sql_delete = "DELETE FROM `data_siswa` WHERE `id` = '"+id+"'";
            PreparedStatement statement = kon.prepareStatement(sql_delete);
            
            statement.execute();
            
        }catch (Exception e){
        }
    }
    
//    public void hapusData (m_Data_Siswa siswa){
//        try{
//            String sql_delete = "DELETE FROM `data_siswa` WHERE `nama` = ? and `tgl_lahir` = ?";
//            PreparedStatement statement = kon.prepareStatement(sql_delete);
//            statement.setString(1, siswa.getNama());
//            statement.setString(2, siswa.getTgl_lahir());
//            statement.executeUpdate();
//            
//            statement.executeUpdate();
//        }catch (Exception e){
//        }
//    }
    
    public void updateData(m_Data_Siswa siswa) {        
        try{
            String sql_update="update `data_siswa` set `nama`=?, `tgl_lahir`=?, "
                    + "`parents`=?, `form`=?, `children`=?, `housing`=?,"
                    + "`finance`=?, `social`=?, `health`=?  where `id`=?";
            PreparedStatement statement = kon.prepareStatement(sql_update);
            statement.setString(1, siswa.getNama());
            statement.setString(2, siswa.getTgl_lahir());
            statement.setInt(3, siswa.getParents());
            statement.setInt(4, siswa.getForm());
            statement.setInt(5, siswa.getChildren());
            statement.setInt(6, siswa.getHousing());
            statement.setInt(7, siswa.getFinance());
            statement.setInt(8, siswa.getSocial());
            statement.setInt(9, siswa.getHealth());
            statement.setInt(10, siswa.getId());
            statement.executeUpdate();
            
            statement.executeUpdate();
        }catch (Exception e){
        }
    }
    
    public int get_nilaiMaxID (){
        int value=0;
        try {
            String sql_count = "SELECT MAX(`id`) FROM `data_siswa`";
            PreparedStatement stmt = kon.prepareStatement(sql_count);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                value = result.getInt(1);
            }
            
        } catch (Exception e){
            
        }
        return value;
    }
}
