/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.*;
/**
 *
 * @author Admin
 */
public class c_Data_User {
    m_Data_User_DAO user_DAO;

    public c_Data_User() {
        this.user_DAO = new m_Data_User_DAO();
    }
    
    public String getPassword(String email){
        return user_DAO.getPassword(email);
    }
}
