/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.m_Data_Bobot_Atribut;
import Model.m_Data_Bobot_Atribut_DAO;
/**
 *
 * @author Admin
 */
public class c_Data_Bobot_Atribut {
    //var global agar bisa dipanggil di semua method dan tidak perlu membuat lagi di setiap method (efisiensi)
    m_Data_Bobot_Atribut_DAO atribut_DAO;
    m_Data_Bobot_Atribut atribut;

public c_Data_Bobot_Atribut(){
    atribut_DAO = new m_Data_Bobot_Atribut_DAO();
}

    public double get_wParents(int id) {
        return atribut_DAO.get_wParents(id);
    }
    
    public int get_bobotParents (int id) {
        return atribut_DAO.get_bobotParents(id);
    }

    public double get_wForm(int id) {
        return atribut_DAO.get_wForm(id);
    }
    
    public int get_bobotForm (int id) {
        return atribut_DAO.get_bobotForm(id);
    }

    public double get_wChildren(int id) {
        return atribut_DAO.get_wChildren(id);
    }
    
    public int get_bobotChldren (int id) {
        return atribut_DAO.get_bobotChildren(id);
    }

    public double get_wHousing(int id) {
        return atribut_DAO.get_wHousing(id);
    }
    
    public int get_bobotHousing (int id) {
        return atribut_DAO.get_bobotHousing(id);
    }

    public double get_wFinance(int id) {
        return atribut_DAO.get_wFinance(id);
    }
    
    public int get_bobotFinance (int id) {
        return atribut_DAO.get_bobotFinance(id);
    }

    public double get_wSocial(int id) {
        return atribut_DAO.get_wSocial(id);
    }
    
    public int get_bobotSocial (int id) {
        return atribut_DAO.get_bobotSocial(id);
    }

    public double get_wHealth(int id) {
        return atribut_DAO.get_wHealth(id);
    }
    
    public int get_bobotHealth (int id) {
        return atribut_DAO.get_bobotHealth(id);
    }
    
    public void update (int parents, int form, int children,int housing, int finance, int social, 
            int health, int total, double w_parents, double w_form, double w_children, double w_housing, 
            double w_finance, double w_social, double w_health) {
        atribut_DAO.update_Atribut(new m_Data_Bobot_Atribut(parents, form, children, housing, finance, social, health, total, 
                w_parents, w_form, w_children, w_housing, w_finance, w_social, w_health));
    }

}
