/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.m_Data_Rekomendasi_DAO;
import Model.m_Data_Rekomendasi;
import java.util.List;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Admin
 */
public class c_Data_Rekomendasi {
    //var Global
    m_Data_Rekomendasi_DAO rekomendasi_DAO;
    
    //konstruktor
    public c_Data_Rekomendasi() {
        rekomendasi_DAO = new m_Data_Rekomendasi_DAO();
    }
    
    DefaultTableModel setTableModel (List<m_Data_Rekomendasi> list_PenerimaBantuan) {
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new Object[] {
        //kolom yang akan ditampilkan
        "Rank", "Nama", "Tgl Lahir", "Vektor S", "Vektor V", "Keterangan"});
        //dimulai dari no.1
        int no=1;
        
        for (m_Data_Rekomendasi supp : list_PenerimaBantuan) {
            tableModel.addRow(new Object[] {
                no,
                supp.getNama(),
                supp.getTgl_lahir(),
                supp.getHasilVektor_S(),
                supp.getHasilVektor_V(),
                keterangan(no)
            });
            update_Rank(supp.getId(), no);
            no++;
    }
        return tableModel;
    }
    
    DefaultTableModel setTableModel1 (List<m_Data_Rekomendasi> list_PenerimaBantuan) {
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new Object[] {
        //kolom yang akan ditampilkan
        "Rank", "Nama", "Tgl Lahir", "Vektor S", "Vektor V", "Keterangan"});
        
        for (m_Data_Rekomendasi supp : list_PenerimaBantuan) {
            tableModel.addRow(new Object[] {
                supp.getRank(),
                supp.getNama(),
                supp.getTgl_lahir(),
                supp.getHasilVektor_S(),
                supp.getHasilVektor_V(),
                keterangan(supp.getRank())
            });
            
    }
        return tableModel;
    }
    
    private String keterangan(int rank){
        if(rank<=50){
            return "Diterima";
        }else {
            return "Tidak Diterima";
        }
    }
    
    public DefaultTableModel TampilkanSemuaDataPenerimaBantuan() {
        List<m_Data_Rekomendasi> DataPenerima = rekomendasi_DAO.getAllDataPenerimaBantuan();
        return setTableModel(DataPenerima);
    }
    
    public DefaultTableModel TampilkanData_byNamadanTglLahir(String nama, String tgl) {
        List<m_Data_Rekomendasi> DataPenerima = rekomendasi_DAO.getData_by_NamadanTglLahir(nama, tgl);
        return setTableModel1(DataPenerima);
    }

    public void Tambah(int id, int rank, String nama, String tgl_lahir, double vektorS, double jumlah_vektorS, double vektorV) {
        rekomendasi_DAO.Tambah(new m_Data_Rekomendasi(id, rank, nama, tgl_lahir, vektorS, jumlah_vektorS, vektorV));
        
    }

    public void update_TotalVektorS(int id, double total_vektorS) {
        rekomendasi_DAO.update_TotalVektorS(id, total_vektorS);
    }
    
    public double getTotalvektorS(int id) {
        return rekomendasi_DAO.getTotalvektorS(id);
    }
    
    public void update_VektorS(int id, double vektorS) {
        rekomendasi_DAO.update_VektorS(id, vektorS);
    }
    
    public void update_Rank(int id, int rank) {
        rekomendasi_DAO.update_Rank(id, rank);
    }

    public double getVektorS(int id) {
        return rekomendasi_DAO.getVektorS(id);
    }    

    public void update_VektorV(int id, double vektorV) {
        rekomendasi_DAO.update_VektorV(id, vektorV);
    }
    
    public void hapus(int id){
        rekomendasi_DAO.hapusData(id);
    }
    
    public void updateData(int id, String nama, String tgl){
        rekomendasi_DAO.updateData(id, nama, tgl);
    }
}
