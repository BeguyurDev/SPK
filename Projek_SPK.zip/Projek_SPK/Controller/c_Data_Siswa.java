/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.m_Data_Siswa_DAO;
import Model.m_Data_Siswa;
import java.util.List;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Admin
 */
public class c_Data_Siswa {
    //var global
    m_Data_Siswa_DAO data_Siswa_DAO;
    
    //konstruktor
    public c_Data_Siswa() {
        data_Siswa_DAO = new m_Data_Siswa_DAO();
    }
    
    DefaultTableModel setTableModel (List<m_Data_Siswa> list_seluruhSiswa) {
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new Object[] {
        //kolom yang akan ditampilkan
        "No", "Nama", "Tgl Lahir", "Parents", "Form", "Chhildren", "Housing", "Finance", "Social", "Health"});
        //dimulai dari no.1
        int no=1;
        for (m_Data_Siswa supp : list_seluruhSiswa) {
            tableModel.addRow(new Object[] {
                no,
                supp.getNama(),
                supp.getTgl_lahir(),
                supp.getParents(),
                supp.getForm(),
                supp.getChildren(),
                supp.getHousing(),
                supp.getFinance(),
                supp.getSocial(),
                supp.getHealth()
            });
            no++;
    }
        return tableModel;
    }
    
    public DefaultTableModel TampilkanSemuaDataSiswa() {
        List<m_Data_Siswa> DataSiswa = data_Siswa_DAO.getAllDataSiswa();
        return setTableModel(DataSiswa);
    }
    
    public DefaultTableModel TampilkanDataSiswa_byNamadanTglLahir(String nama, String tgl) {
        List<m_Data_Siswa> DataSiswa = data_Siswa_DAO.getDataby_NamadanTglLahir(nama, tgl);
        return setTableModel(DataSiswa);
    }
    
    public int getID(int id){
        return data_Siswa_DAO.getID(id);
    }
    
    public int getID_byNamadanTglLahir(String nama, String tgl){
        return data_Siswa_DAO.getID_byNamadanTglLahir(nama, tgl);
    }

    public String getNama(int id) {
        return data_Siswa_DAO.getNama(id);
    }

    public String getTglLahir(int id) {
        return data_Siswa_DAO.getTglLahir(id);
    }
    
    public int getBobotParentsSiswa(int id) {
        return data_Siswa_DAO.getBobotParentsSiswa(id);
    }
    
    public int getBobotFormSiswa (int id) {
        return data_Siswa_DAO.getBobotFormSiswa(id);
    }
    
    public int getBobotChildrenSiswa (int id) {
        return data_Siswa_DAO.getBobotChildrenSiswa(id);
    }
    
    public int getBobotHousingSiswa (int id) {
        return data_Siswa_DAO.getBobotHousingSiswa(id);
    }
    
    public int getBobotFinanceSiswa (int id) {
        return data_Siswa_DAO.getBobotFinanceSiswa(id);
    }
    
    public int getBobotSocialSiswa (int id) {
        return data_Siswa_DAO.getBobotSocialSiswa(id);
    }
    
    public int getBobotHealthSiswa (int id) {
        return data_Siswa_DAO.getBobotHealthSiswa(id);
    }
    
    public void editTglLahir(String tgl_lahir){
        data_Siswa_DAO.editTglLahir(new m_Data_Siswa(tgl_lahir));
    }
    
    public void TambahData(String nama, String tgl_lahir, int parents, int form, int children, int housing, int finance, int social, int health){
        data_Siswa_DAO.Tambah(new m_Data_Siswa(nama, tgl_lahir, parents, form, children, housing, finance, social, health));
    }
    
    public void Hapus(int id){
        data_Siswa_DAO.hapusData(id);
    }
    
//    public void Hapus(String nama, String tgl){
//        data_Siswa_DAO.hapusData(new m_Data_Siswa(nama, tgl));
//    }
    
    public void updateData (int id, String nama, String tgl_lahir, int parents, int form, int children, int housing, int finance, int social, int health) {
        data_Siswa_DAO.updateData(new m_Data_Siswa(id, nama, tgl_lahir, parents, form, children, housing, finance, social, health));
    }
    
    public int getMaxID (){
        return data_Siswa_DAO.get_nilaiMaxID();
    }
}
